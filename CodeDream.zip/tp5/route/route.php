<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

// view:
Route::rule('/index', 'index/Index/index'); //课程主页
Route::rule("/course/newcourse", 'index/Ccourse/newcourse'); 
Route::rule("/course/course", 'index/Ccourse/course');
Route::rule("/course/managecourse", 'index/Ccourse/managecourse');
Route::rule('/login/page', 'index/Login/page'); 
Route::rule('/login/box', 'index/Login/box');

Route::rule('/test', 'index/Abx/index');

//自己添加的
Route::rule("/compiler", 'index/Compiler/compiler');



// login
Route::rule('/login/register', 'index/Login/register');
Route::rule('/login/login', 'index/Login/login');
Route::rule('/login/logout', 'index/Login/logout');
Route::rule('/login/judge', 'index/Login/judge');

// Course
Route::rule("/course/getCourse", 'index/Ccourse/getCourse');
Route::rule("/course/getCourseList", 'index/Ccourse/getCourseList');
Route::rule("/course/getChapter", 'index/Ccourse/getChapter');
Route::rule("/course/getContent", 'index/Ccourse/getContent');
Route::rule("/course/getContent0", 'index/Ccourse/getContent0');


Route::rule("/course/addCourse", 'index/Ccourse/addCourse');
Route::rule("/course/addChapter", 'index/Ccourse/addChapter');
Route::rule("/course/addSection", 'index/Ccourse/addSection');

Route::rule("/course/editCourse", 'index/Ccourse/editCourse');
Route::rule("/course/editSection", 'index/Ccourse/editSection');



//messageboard
//Route::rule('Cblog/index', 'index/Cblog/index');
Route::rule('blog/stack', 'index/Cblog/stack');
Route::rule('blog/blog', 'index/Cblog/blog');
Route::rule('blog/post', 'index/Cblog/post');

Route::rule('/blog/getBlogList', 'index/Cblog/getBlogList');
//Route::rule('/cblog/getIndexList', 'index/Cblog/getIndexList');
Route::rule('/blog/getNew', 'index/Cblog/getNew');

Route::rule('/blog/enter', 'index/Cblog/enter');
Route::rule('/blog/getBlog', 'index/Cblog/getBlog');

Route::rule('/blog/addBlog', 'index/Cblog/addBlog');
Route::rule('/blog/modifyBlog', 'index/Cblog/modifyBlog');
Route::rule('/blog/deleteBlog', 'index/Cblog/deleteBlog');

Route::rule('/blog/collect', 'index/Cblog/collect');
Route::rule('/blog/cancelCollect', 'index/Cblog/cancelCollect');

Route::rule('/blog/replyComment', 'index/Cblog/replyComment');
Route::rule('/blog/modifyComment', 'index/Cblog/modifyComment');
Route::rule('/blog/deleteComment', 'index/Cblog/deleteComment');

//personalcenter
Route::rule('/user/center', 'index/Personalcenter/center');
Route::rule('/user/getAllInfo', 'index/Personalcenter/getAllInfo');
Route::rule('/user/modify', 'index/Personalcenter/modify');
Route::rule('/user/deleteBlog', 'index/Personalcenter/deleteBlog');
Route::rule('/user/concentrate', 'index/Personalcenter/concentrate');



//自己添加的a
Route::rule("/course/selectCourse", 'index/Ccourse/selectCourse');

Route::rule("/course/deleteCourse", 'index/Ccourse/deleteCourse');
Route::rule("/course/deleteChapter", 'index/Ccourse/deleteChapter');
Route::rule("/course/deleteSection", 'index/Ccourse/deleteSection');











return [

];


