<?php /*a:1:{s:63:"/var/www/html/tp5/application/index/view/ccourse/newcourse.html";i:1544978537;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <link rel="shortcut icon" href="/static/images/favicon/favicon.png" type="image/x-icon">
    <link rel="icon" href="/static/images/favicon/favicon.png" type="image/x-icon">

    <title>Code Dream</title>
    
    <!--Library Styles-->    
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/css/lib/font-awesome.css" rel="stylesheet">
    <link href="/static/css/lib/nivo-lightbox.css" rel="stylesheet">
    <link href="/static/css/lib/nivo-themes/default/default.css" rel="stylesheet">
    
    <!--Template Styles-->
    <link href="/static/css/style.css" rel="stylesheet">
    <link href="/static/css/scheme/purple.css" rel="stylesheet">
    <style>
        .always-hide{
            display: none;
        }
        .always-delete-hide{
            display: none;
        }
        .scroll:hover .always-hide{
            display: inline;
        }
        .scroll:hover .always-delete-hide{
            display: inline;
            font-size: x-small;
            color: #FF0000;
        };
        .deleteChapterbtn{ border-radius:4px； background-color：yellow;}
/*<--引用样式--!>*/
    blockquote {
        border-left:#eee solid 5px;
        padding-left:20px;
    }
/*<--列表样式--!>*/
    ul li {
        line-height: 20px;
    }
/*代码样式*/
    code {
        color:#D34B62;
        background: #F6F6F6;
    }
    </style>
    <script type="text/javascript" src="/static/js/showdown-master/dist/showdown.min.js"></script>

    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

<body data-spy="scroll">

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
    
    <div id="main-wrapper">
        
        <!-- Site Navigation -->
        <div id="menu">
            <nav class="navbar navbar-default" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html#">
                        <img src="/static/images/logo.png" alt="logo">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a class="scroll" href="/index">主页</a></li>
                        <li><a id="courseIndex" class="scroll">课程</a></li>
                        <li><a class="sscroll" href="index.html#add-courses">增加课程</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    
        <div id="container">
            <!-- BEGIN HOME -->
            <section id="home"  style="background-image: url(/static/images/study.gif)  ;height:650px;background-size: 100% 100%;">
                <div class="row ">
                    <div class="col-md-12">
                        <div class="header-content">
                    <h1>完善课程</h1>
                    <br/>
                    <h3>本网站主要有两大功能：</h3>
                    <h3>一是添加新课程，完善网站的课程体系；</h3>
                    <h3>二是补充修改课程内容，查漏补缺，与时俱进。</h3>
                </div>
            </div>
                </div>
            </section>
           
            <!-- END HOME -->
            
            <!-- BEGIN SERVICES -->
            <section id="services" class="services">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header-content">
                            <h2>课程</h2>
                            <h3>以下是我们目前提供的课程</h3>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row" id = "course-map-row">

                        </div>
                    </div>                   
                </div>
            </section>
            <!-- END SERVICES -->



            <!-- BEGIN CONTACT -->
            <section id="add-courses" class="addcourses">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header-content">
                            <h2>增加课程</h2>
                        </div>
                        <div class="div">
                            <form action="#" method="post" text-align:center >
                                <div class="field">
                                    <input name="course" id="new_course" type="text" placeholder="课程名" class="form-control">
                                </div>
                                <br/>
                                <label for="pre_course"  >前置课程：</label><br/>
                                <form>
                                    <select name="pre_course" id="_label" class="form-control">
                                        <option disabled="disabled">课程名</option>
                                        <option value="-1">无前置课程</option>
                                    </select>
                                </form>
                                <br/>
                                <label for="descrip">课程简介：</label><br/>
                                <textarea name="course-short-summary" id="course-short-summary"  placeholder="课程简介(字数在70以内）" class="form-control"   style="height: 50px" placeholder="课程简介"> </textarea>
                                <br/>
                                <label for="descrip">课程介绍：</label><br/>
                                <textarea name="course-long-summary" id="course-long-summary"  placeholder="课程介绍" class="form-control"   style="height: 300px" onkeyup="convert()"> </textarea>
                                <br/>
                                <div id="result" style="height:500px; background-color: white;"></div>
                                <div>
                                    <button id="create-course" type="submit" class="btn btn-primary btn-lg" style="background-color: gray;border-color:gray;">新建课程</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
                           <!-- BEGIN FOOTER -->

                                       <!-- BEGIN CONTACT -->
            
            <footer>
                <div class="row">
                    <div class="col-md-12">
                        <p>
                            我们项目组
                        </p>               
                    </div>
                </div>
            </footer>
            <!-- END FOOTER -->


    <!-- Back to top -->
    <div id="backtotop">       
        <a class="to-top-btn sscroll" href="index.html#home"><i class="fa fa-angle-double-up"></i></a>
    </div>


    <!-- Library Scripts -->
    <script src="/static/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/lib/jquery.preloader.js"></script>
    <script src="/static/js/lib/nivo-lightbox.min.js"></script>
    <script src="/static/js/bootstrap.min.js"></script>
    <script src="/static/js/lib/jquery.superslides.min.js"></script>
    <script src="/static/js/lib/smoothscroll.js"></script>
    <script src="/static/js/lib/jquery.bxslider.min.js"></script>
    <script src="/static/js/lib/jquery.mixitup.min.js"></script>
    <script src="/static/js/lib/jquery.backtotop.js"></script>
    <script src="/static/js/lib/jquery.carouFredSel-6.2.1-packed.js"></script>
    <script src="/static/js/lib/retina.min.js"></script>
    <script src="/static/js/jquery-1.10.2.min.js"></script>

    <!-- Custom Script -->    
    <script src="/static/js/main.js"></script>
    <script type="text/javascript" src="/static/js/jquery-1.10.2.min.js"></script>
    
</body>
<script src="/static/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript">
    window.onload = function(){
        $.ajax({
            type: "GET",
            url: "http://134.175.38.49/index.php/course/getCourseList",
            data: {},
            dataType: "json",
            success: function(data){
                data = $.parseJSON(data);
                var value = 0;
                var courseIndex = document.getElementById("courseIndex");
                var courseSelectIndex = document.getElementById("_label");
                var courseArr = data["courseList"];
                for (var i = 0; i < courseArr.length; i++){
                    var branch = i % 3;
                    var liTemp = document.createElement("li");
                    var aTemp = document.createElement("a");
                    aTemp.className = "scroll always-hide";
                    aTemp.innerHTML = courseArr[i]["name"];
                    var deleteATemp=document.createElement("a");
                    deleteATemp.className = "scroll always-delete-hide";
                    deleteATemp.innerHTML = "        删除";

                    deleteATemp.id=courseArr[i]["courseID"];
                    aTemp.id = "course" + courseArr[i]["courseID"];
                    aTemp.href = "javascript: jumpToEditCoursePage(" + courseArr[i]["courseID"] + ");";
                    deleteATemp.href="javascript: DeleteCourse("+courseArr[i]["courseID"] + ");";
                    
                    liTemp.appendChild(aTemp);
                    liTemp.appendChild(deleteATemp);
                    courseIndex.append(liTemp);

                    var optionTemp = document.createElement("option");
                    optionTemp.innerHTML = courseArr[i]["name"];
                    optionTemp.value = courseArr[i]["courseID"];
                    courseSelectIndex.append(optionTemp);

                    var targetCourseMapDiv = document.getElementById("course-map-row");

                    var colDivTemp = document.createElement("div");
                    var courseDivTemp = document.createElement("div");
                    var iconHolderDivTemp = document.createElement("div");
                    var courseITemp = document.createElement("i");
                    var courseHTemp = document.createElement("h3");
                    var courseDescriptionPTemp = document.createElement("p");
                    colDivTemp.className = "col-md-4 col-sm-6 col-xs-12";
                    courseDivTemp.className = "service";
                    iconHolderDivTemp.className = "icon-holder";
                    switch(branch){
                        case 0:
                        {
                            courseITemp.className = "fa fa-paper-plane";
                            break;
                        }
                        case 1:
                        {
                            courseITemp.className = "fa fa-diamond";
                            break;
                        }
                        case 2:
                        {
                            courseITemp.className = "fa fa-camera";
                            break;
                        }
                        case 3:
                        {
                            courseITemp.className = "fa fa-heartbeat";
                            break;
                        }
                    }
                    courseHTemp.className = "heading";
                    courseDescriptionPTemp.className = "description";
                    iconHolderDivTemp.append(courseITemp);
                    courseHTemp.innerHTML = courseArr[i]["name"];
                    courseDescriptionPTemp.innerHTML = courseArr[i]["profile"];
                    courseDivTemp.append(iconHolderDivTemp);
                    courseDivTemp.append(courseHTemp);
                    courseDivTemp.append(courseDescriptionPTemp);
                    colDivTemp.append(courseDivTemp);
                    targetCourseMapDiv.append(colDivTemp);
                }
            },
            error : function(data){
                //alert("error");
            }
        })
    };
    function convert(){
        //var text = document.getElementById("course-long-summary").value;
        var text = $("#course-long-summary").val();
        var converter = new showdown.Converter();
        var html = converter.makeHtml(text);
        document.getElementById("result").innerHTML = html;
    };
    function jumpToEditCoursePage(i){
        $.ajax({
            type : "POST",
            url : "/course/selectCourse",
            data : {courseID : i},
            dataType : "json",
            success : function(data){
                window.location.href = "http://134.175.38.49/course/managecourse";
            }
        })
    };
    function DeleteCourse(j){
        $.ajax({
            type : "POST",
            url : "/course/deleteCourse",
            data : {courseID:j},
            dataType : "json",
            success : function(data){
                data = $.parseJSON(data);
                if (data["responseStatus"] === 0)
                    {
                        alert("课程删除成功");
                        window.location.reload(true);
                    }
                else
                    {
                        alert("课程删除失败");
                    }
            },
            error : function(data){
                //alert("error");
            }
        });
    };
    $("#create-course").click(function(){
        $.ajax({
        type: "POST",
        url: "/course/addCourse",
        data: {courseName : $("#new_course").val(), preCourseID : $("#_label").val(), shortSummary : $("#course-short-summary").val(), longSummary:$("#course-long-summary").val()},
        dataType: "json",
        success: function(data){
            data = $.parseJSON(data);
            if(data["responseStatue"]===0){
                alert("课程新建成功");
                window.location.reload(true);
                //document.getElementById("_")
            }
            else{
                alert("课程新建失败");
            }
          
        },
        error: function(data){
            //alert("error");
        }
    });
    })
</script>

</html>