<?php /*a:1:{s:56:"/var/www/html/tp5/application/index/view/login/page.html";i:1544955056;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0097)https://passport.zcool.com.cn/loginApp.do?appId=1006&cback=https://my.zcool.com.cn/focus/activity -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script src="./用户登录 - 通行证 - 站酷_files/hm.js.下载"></script>
<title>通行证 - Code Dream</title>



<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<link href="/static/css/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css">
<link href="/static/css/common.css" rel="stylesheet" type="text/css">
<link href="/static/css/passnumberbind.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="/static/images/favicon/favicon.png" type="image/x-icon">
<link rel="icon" href="/static/images/favicon/favicon.png" type="image/x-icon">


<style>
#nc_1_captcha_input {border: solid 1px #999;}
</style>


<body>
<div class="pass-main-body">
	<input type="hidden" id="thirdLogin" name="thirdLogin" value="">
	<div class="pass-header-wrap">

        <div class="login-passcard-nav">
	        <a href="./index.html" class="login-zcool-logo">CodeDream</a>通行证
        </div>

	</div>
	
	  
	<div class="login-logo">
		<a href="./index.html" class="cool-logo"><img src="/static/images/pass-logo.png"></a>
		<br>
		登录Code Dream，与我们一起交流设计、分享快乐吧！
    </div>
	
	<!-- 通行证默认登录页面 -->
	<div class="login-div-box">
		<iframe allowtransparency="true" id="loginChild" name="loginChild" scrolling="no" src="/login/box" style="background-color:transparent" marginwidth="0" frameborder="0" width="400" height="500"></iframe>
	</div>
	
	<!-- iframe方式引用通行证登录框页面 -->
		
    <div class="footer login-footer">
	    <p>我们项目组</p>
    </div>
	
</div>

</body>

</html>