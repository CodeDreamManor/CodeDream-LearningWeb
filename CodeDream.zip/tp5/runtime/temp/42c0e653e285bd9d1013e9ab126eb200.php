<?php /*a:1:{s:63:"/var/www/html/tp5/application/index/view/compiler/compiler.html";i:1544964491;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <link rel="shortcut icon" href="/static/images/favicon/favicon.png" type="image/x-icon">
    <link rel="icon" href="/static/images/favicon/favicon.png" type="image/x-icon">

    <title>Code Dream</title>
    
    <!--Library Styles-->    
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/css/lib/font-awesome.css" rel="stylesheet">
    <link href="/static/css/lib/nivo-lightbox.css" rel="stylesheet">
    <link href="/static/css/lib/nivo-themes/default/default.css" rel="stylesheet">
    
    <!--Template Styles-->
    <link href="/static/css/style.css" rel="stylesheet">
    <link href="/static/css/scheme/purple.css" rel="stylesheet">
    <style>
        .always-hide{
            display: none;
        }
        .scroll:hover .always-hide{
            display: block;
        }
/*<--引用样式--!>*/
    blockquote {
        border-left:#eee solid 5px;
        padding-left:20px;
    }
/*<--列表样式--!>*/
    ul li {
        line-height: 20px;
    }
/*代码样式*/
    code {
        color:#D34B62;
        background: #F6F6F6;
    }
    </style>

    <!--[if lt IE 9]>
      <script src="/static/js/html5shiv.js"></script>
      <script src="/static/js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript" src="/static/js/showdown-master/dist/showdown.min.js"></script>
</head>

<body data-spy="scroll">

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
    
    <div id="main-wrapper">
        
        <!-- Site Navigation -->
        <div id="menu">
            <nav class="navbar navbar-default" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html#">
                        <img src="/static/images/logo.png" alt="logo">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="/index">主页</a></li>
                        <li><a id="courseIndex" class="scroll">课程</a></li>
                        <li><a class="sscroll" href="/compiler">在线编译</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    
        <div id="container">
            <!-- BEGIN CONTACT -->
            <section id="add-courses" class="addcourses">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header-content">
                            <h2>在线编译</h2>
                        </div>
                        <div class="col-sm-6 col-md-6">
                            <form action="#" method="post" text-align:center >
                                <label for="pre_language"  >采用语言：</label><br/>
                                <form>
                                    <select name="pre_course" id="_label" class="form-control">
                                        <option disabled="disabled">课程名</option>
                                        <option value="html">HTML</option>
                                        <option value="css">CSS</option>
                                        <option value="javascript">JavaScript</option>
                                        <option value="php">PHP</option>
                                    </select>
                                </form>
                                <label for="descrip">代码：</label><br/>
                                <textarea name="course_des" id="code"  placeholder="代码" class="form-control"   style="height: 300px" placeholder="代码"  onkeyup="convert()"> </textarea>
                                <br/>
                                <div>
                                    <button id="code-post" type="submit" class="btn btn-primary btn-lg" style="background-color: gray;border-color:gray;">测试</button>
                                </div>
                            </form>
                        </div>
                        <div id="result" class="col-sm-6 col-md-6" style="height:500px; background-color: #E8E8E8; border-radius: 10px;"></div>
                    </div>
                </div>
            </section>
                           <!-- BEGIN FOOTER -->

                                       <!-- BEGIN CONTACT -->
            
            <footer>
                <div class="row">
                    <div class="col-md-12">
                        <p>
                            我们项目组
                        </p>               
                    </div>
                </div>
            </footer>
            <!-- END FOOTER -->


    <!-- Back to top -->
    <div id="backtotop">       
        <a class="to-top-btn sscroll" href="index.html#home"><i class="fa fa-angle-double-up"></i></a>
    </div>


    <!-- Library Scripts -->
    <script src="/static/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/lib/jquery.preloader.js"></script>
    <script src="/static/js/lib/nivo-lightbox.min.js"></script>
    <script src="/static/js/bootstrap.min.js"></script>
    <script src="/static/js/lib/jquery.superslides.min.js"></script>
    <script src="/static/js/lib/smoothscroll.js"></script>
    <script src="/static/js/lib/jquery.bxslider.min.js"></script>
    <script src="/static/js/lib/jquery.mixitup.min.js"></script>
    <script src="/static/js/lib/jquery.backtotop.js"></script>
    <script src="/static/js/lib/jquery.carouFredSel-6.2.1-packed.js"></script>
    <script src="/static/js/lib/retina.min.js"></script>
    <script src="/static/js/jquery.min.js"></script>

    <!-- Custom Script -->    
    <script src="/static/js/main.js"></script>
    <script type="text/javascript" src="/static/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="showdown-master/dist/showdown.min.js"></script>
    
</body>
<script src="/static/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript">
    window.onload = function(){
        $.ajax({
            type: "GET",
            url: "/course/getCourseList",
            data: {},
            dataType: "json",
            success: function(data){
                data = $.parseJSON(data);
                var value = 0;
                var courseIndex = document.getElementById("courseIndex");
                var courseSelectIndex = document.getElementById("_label");
                var courseArr = data["courseList"];
                for (var i = 0; i < courseArr.length; i++){
                    var liTemp = document.createElement("li");
                    var aTemp = document.createElement("a");
                    aTemp.className = "scroll always-hide";
                    aTemp.innerHTML = courseArr[i]["name"];
                    aTemp.href = "javascript: jumpToCoursePage(" + courseArr[i]["courseID"] + ");";

                    aTemp.id = "course" + courseArr[i]["courseID"];
                    liTemp.appendChild(aTemp);
                    courseIndex.append(liTemp);
                }
            },
            error : function(data){
                alert("error");
            }
        })
    };
    function convert(){
    };
    $("#code-post").click(function(){
        var code = document.getElementById("code").value;
        var converter = new showdown.Converter();
        var convertedCode = converter.makeHtml(code);
        var targetDiv = document.getElementById("result");
        targetDiv.innerHTML = convertedCode;
    });
    function jumpToCoursePage(i){
        $.ajax({
            type : "POST",
            url : "/course/selectCourse",
            data : {courseID : i},
            success : function(data){
                data = $.parseJSON(data);
                //alert("success!!!");
                $(window).attr('location','/course/course');
            },
            error : function(data){
                alert("error");
            }
        })
    };
</script>

</html>