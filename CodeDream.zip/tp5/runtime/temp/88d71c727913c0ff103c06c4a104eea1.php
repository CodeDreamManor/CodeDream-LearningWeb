<?php /*a:1:{s:60:"/var/www/html/tp5/application/index/view/ccourse/course.html";i:1544980026;}*/ ?>
<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	
    <link rel="shortcut icon" href="/static/images/favicon/favicon.png" type="image/x-icon">
    <link rel="icon" href="/static/images/favicon/favicon.png" type="image/x-icon">

    <title>课程</title>
	
    <!--Library Styles-->
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/css/lib/font-awesome.css" rel="stylesheet">
    <link href="/static/css/lib/nivo-lightbox.css" rel="stylesheet">
    <link href="/static/css/lib/nivo-themes/default/default.css" rel="stylesheet">
	
    <!--Template Styles-->
    <link href="/static/css/style.css" rel="stylesheet">
    <link href="/static/css/scheme/purple.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="/static/js/html5shiv.js"></script>
      <script src="/static/js/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .always-hide{
            display: none;
        }
        .sscroll:hover .always-hide{
            display: block;
        }
    </style>

    <script type="text/javascript" src="/static/js/showdown-master/dist/showdown.min.js"></script>
</head>

<body data-spy="scroll">

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
    <div id="main-wrapper">
        <div id="menu">
            <nav class="navbar navbar-default" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html#">
                        <img src="/static/images/logo.png" alt="logo">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-navbar-collapse">
                    <ul class="nav navbar-nav" id = "ul-menu">
                        <li id = "index"><a href="/index">主页</a></li>
                        <li><a href="/compiler" class="nav-unlogin">在线编译</a>
                        <!-- <li><a href="/login/page" class="nav-unlogin">登录|注册</a> -->
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </nav>
        </div>
        <div id="container">

            <!-- BEGIN BLOG -->
            <section id="course-content" class="blog">
                <div class="row">
                    <div class="col-md-12">
                        <div id="primary" class="row">
                            <div class="col-md-12">
                                <!-- BEGIN ARTICLE -->
                                <article class="post">
                                    <div class="post-thumb">
                                        <a href="html-course.html">
                                            <img id = "static-img" src="/static/images/post-2.jpg" alt="Blog Post 1" />
                                        </a>
                                    </div>
                                    <div class="post-title">
                                        <h1 id="title">HTML
                                        </h1>
                                    </div>
                                    <div class="post-content" id="article-content">
                                        <p>万维网上的一个超媒体文档称之为一个页面（外语：page）。作为一个组织或者个人在万维网上放置开始点的页面称为主页（外语：Homepage）或首页，主页中通常包括有指向其他相关页面或其他节点的指针（超级链接），所谓超级链接，就是一种统一资源定位器（Uniform Resource Locator，外语缩写：URL）指针，通过激活（点击）它，可使浏览器方便地获取新的网页。这也是HTML获得广泛应用的最重要的原因之一。在逻辑上将视为一个整体的一系列页面的有机集合称为网站（Website或Site）。超级文本标记语言（英文缩写：HTML）是为“网页创建和其它可在网页浏览器中看到的信息”设计的一种标记语言。</p>
                                       
                                    </div>
                                </article>
                                <!-- END ARTICLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END BLOG -->
            
            <!-- BEGIN FOOTER -->
            <footer>
                <div class="row">
                    <div class="col-md-12">
                        <p>
                           我们项目组
                        </p>                        
                    </div>
                </div>
            </footer>
            <!-- END FOOTER -->
        </div>
    </div>



    <!-- Back to top -->
    <div class="totop" id="backtotop">       
        <a class="to-top-btn sscroll" href="index.html#home"><i class="fa fa-angle-double-up"></i></a>
    </div>

    <!-- Library Scripts -->
    <script src="/static/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/lib/jquery.preloader.js"></script>
    <script src="/static/js/lib/nivo-lightbox.min.js"></script>
    <script src="/static/js/bootstrap.min.js"></script>
    <script src="/static/js/lib/jquery.superslides.min.js"></script>
    <script src="/static/js/lib/smoothscroll.js"></script>
    <!--<script src="/static/js/lib/jquery.sudoslider.min.js"></script>-->
    <script src="/static/js/lib/jquery.bxslider.min.js"></script>
    <script src="/static/js/lib/jquery.mixitup.min.js"></script>
    <script src="/static/js/lib/jquery.backtotop.js"></script>
    <script src="/static/js/lib/jquery.carouFredSel-6.2.1-packed.js"></script>
    <script src="/static/js/lib/retina.min.js"></script>

    <!-- Custom Script -->    
    <script src="/static/js/main.js"></script>
</body>
<script src="/static/js/jquery-1.10.2.min.js"></script>
<script type = "text/javascript">
    var chapterArr;
    
    window.onload = function(){

        $.ajax({
            type : "GET",
            url : "/course/getChapter",
            data : {},
            dataType : "json",
            success : function(data){
                data = $.parseJSON(data);
                chapterArr = data["chapter"];
                //alert(chapterArr[0]["name"]);
                //alert(chapterArr.length);
                var targetUl = document.getElementById("ul-menu");
                var index = document.getElementById("index");
                for (var i = chapterArr.length - 1; i >= 0; i--){
                    var liTemp = document.createElement("li");
                    var aTemp = document.createElement("a");
                    aTemp.className = "sscroll";
                    aTemp.innerHTML = chapterArr[i]["chapterName"];
                    //aTemp.style = "display : block";
                    aTemp.id = "chapter" + i;
                    liTemp.appendChild(aTemp);
                    
                    //targetUl.prepend(liTemp);
                    index.after(liTemp);
                    var cTemp = "chapter" + i;
                    //index = document.getElementById(cTemp);

                    var sectionIndex = document.getElementById(cTemp);;

                    var sectionArr = chapterArr[i]["section"];
                    //alert(sectionArr.length);
                    for(var j = 0; j < sectionArr.length; j++){
                        var sectionLiTemp = document.createElement("li");
                        var sectionATemp = document.createElement("a");
                        sectionATemp.className = "sscroll always-hide";
                        sectionATemp.innerHTML = sectionArr[j]["sectionName"];
                        //sectionATemp.href = "javascript:void(0);";
                        //sectionATemp.href = "javascript:changeArticle(event);";
                        sectionATemp.href = "javascript:changeArticle(" + chapterArr[i]["chapterID"] + "," + sectionArr[j]["sectionID"] + ");";
                        //sectionATemp.onclick = "editPosition($(this));";
                        sectionLiTemp.append(sectionATemp);
                        var sTemp = "section" + chapterArr[i]["chapterID"] + "-" + sectionArr[j]["sectionID"];
                        sectionLiTemp.id = "section" + chapterArr[i]["chapterID"] + "-" + sectionArr[j]["sectionID"];
                        /*
                        $("#sTemp").on("click", "li", function(){
                            alert("success!!!");
                        });
                        */
                        sectionIndex.append(sectionLiTemp);
                        //sectionIndex = document.getElementById("section" + i + "-" + j);
                    }
                }
                $.ajax({
                    type : "GET",
                    url : "/course/getCourse",
                    data : {},
                    dataType : "json",
                    success : function(data){
                        data = $.parseJSON(data);
                        if (data["responseStatus"] === 0){
                            $("#title").text(data["name"]);
                            var summary = data["summary"];
                            var converter = new showdown.Converter();
                            var convertedSummary = converter.makeHtml(summary);
                            var targetDiv = document.getElementById("article-content");
                            targetDiv.innerHTML = convertedSummary;
                        }
                    },
                    error : function(data){
                        alert("error");
                    }
                })
            },
            error : function(data){
                alert("error");
            }
        })
    };
    function changeArticle(i,j){
    	$.ajax({
    		type : "GET",
    		url : "/course/getContent",
    		data : {sectionID : j},
    		dataType : "json",
    		success : function(data){
                //alert(data);
                $("#static-img").hide();
                //data = JSON.parse(data);
                data = $.parseJSON(data);
                $("#title").text(data["title"]);
    			$("#article-content").empty();
    			var sectionContent = data["content"];
    			var converter = new showdown.Converter();
                var convertedSummary = converter.makeHtml(sectionContent);
                var targetDiv = document.getElementById("article-content");
                targetDiv.innerHTML = convertedSummary;
    		}
    	})
    }
    /*
    $(document).click(function changeArticle(obj,event){
        //alert("success!!!");
        var $target = $(event.target);
        if( $target.is("li") ) {
            $target.children().toggle();
        };
        var input = $(event.target).nodeName;//obj.parent.id;
        alert(input);
        var indexOfChapter = 1;
        var j;
        var destSectionArr = chapterArr[indexOfChapter]["section"];
        var sectionContent = destSectionArr[j]["sectionContent"];
    })
    */
    /*,
    $(document).ready(function(){
        $
    })
    function substitute(){
        var input = event.target.parentElement.id;
        alert(input);
        var i;
        var j;
        var destSectionArr = chapterArr[indexOfChapter]["section"];
        var sectionContent = destSectionArr[j]["sectionContent"];
    }
    */
</script>

</html>
