<?php
/**
 * Created by PhpStorm.
 * User: Zedom
 * Date: 2018/12/8
 * Time: 16:43
 */

namespace app\index\controller;


use think\Request;

class Compiler
{
    /**
     * Writer:      吴潘安
     * Date:        2018/12/8
     * Function:    返回在线编辑页面
     */
    public function compiler(){
        return view();
    }
}