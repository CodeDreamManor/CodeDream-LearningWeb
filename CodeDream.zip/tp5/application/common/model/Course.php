<?php
/**
 * Created by PhpStorm.
 * User: Zedom
 * Date: 2018/12/7
 * Time: 11:09
 */

namespace app\common\model;


use think\Model;

class Course extends Model
{

}