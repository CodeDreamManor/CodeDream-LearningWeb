<?php

namespace app\common\model;

use think\Model;

class Message extends Model
{
    //
}