<?php

namespace app\common\model;

use think\Model;

class Dailystudy extends Model
{
    //
}
