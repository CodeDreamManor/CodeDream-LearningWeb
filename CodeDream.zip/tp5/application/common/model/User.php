<?php
/**
 * Created by PhpStorm.
 * User: Zedom
 * Date: 2018/11/28
 * Time: 12:28
 */

namespace app\common\model;


use think\Model;

class User extends Model
{

}