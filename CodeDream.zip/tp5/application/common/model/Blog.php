<?php
/**
 * Created by PhpStorm.
 * User: bluei
 * Date: 2018/12/7
 * Time: 9:22
 */
namespace app\common\model;

use think\Model;

class Blog extends Model
{
    //
}